import React from "react";
import {
  ArrowUpRight,
  Building2,
  CalendarCheck,
  Check,
  Droplets,
  Hammer,
  House,
  Leaf,
  Mail,
  MapPin,
  Phone,
  Quote,
  ShieldCheck,
  Sofa,
  Sparkles,
} from "lucide-react";

// ─── Data ───────────────────────────────────────────────────────────────────

const services = [
  {
    icon: House,
    title: "Residential Refresh",
    description:
      "Weekly, bi-weekly, or one-off deep cleans tailored to your home. We handle the dust you forgot was there.",
    keywords: ["Bedrooms", "Kitchens", "Baths", "Floors"],
    span: "col-span-12 sm:col-span-6 md:col-span-4",
  },
  {
    icon: Building2,
    title: "Commercial & Office",
    description:
      "After-hours sparkle for offices, clinics, and storefronts across the region.",
    keywords: ["Offices", "Clinics", "Retail"],
    span: "col-span-12 sm:col-span-6 md:col-span-4",
  },
  {
    icon: Hammer,
    title: "Post-Construction",
    description:
      "Drywall dust, paint flecks, sticker glue — gone before the keys change hands.",
    keywords: ["Renos", "New builds"],
    span: "col-span-12 sm:col-span-6 md:col-span-4",
  },
  {
    icon: Sofa,
    title: "Move-In / Move-Out",
    description:
      "A spotless reset between tenants. Inspector-ready, deposit-friendly.",
    keywords: ["Rentals", "Sales"],
    span: "col-span-12 sm:col-span-6 md:col-span-6",
  },
  {
    icon: Droplets,
    title: "Window & Glass",
    description:
      "Streak-free, lint-free, fingerprint-free. The view is the whole point.",
    keywords: ["Interior", "Exterior"],
    span: "col-span-12 sm:col-span-6 md:col-span-6",
  },
];

const process = [
  {
    n: "01",
    title: "You set the scope",
    body: "Walk us through what you want done — room by room, top to bottom, or a short focused list. Your priorities, your call.",
  },
  {
    n: "02",
    title: "Honest hourly rate",
    body: "No flat-fee guesswork. You pay only for the hours we are actually on site, with the rate confirmed up front.",
  },
  {
    n: "03",
    title: "We work until it is done",
    body: "No clock-watching, no half-finished rooms. We stay on the list you set until every item is checked off.",
  },
  {
    n: "04",
    title: "Eight hours, hard cap",
    body: "Our crew tops out at eight hours per day. Larger jobs continue the next visit — fresh eyes, no fatigued shortcuts.",
  },
];

const testimonials = [
  {
    quote:
      "Quiet, careful, and they actually move things to clean under them. The kitchen looked the way it did the day we moved in.",
    name: "M. Tremblay",
    role: "Homeowner, St. Catharines",
    initials: "MT",
  },
  {
    quote:
      "Booked them for a post-reno tidy and they took it seriously. Walked back in the next morning and the space was ready to use.",
    name: "D. Kapoor",
    role: "Office manager, Niagara Falls",
    initials: "DK",
  },
  {
    quote:
      "Polite, on time, and they remember the small things from one visit to the next. That counts for a lot.",
    name: "R. O'Donnell",
    role: "Bi-weekly client",
    initials: "RO",
  },
];

const cities = [
  "Niagara-on-the-Lake",
  "St. Catharines",
  "Niagara Falls",
  "Welland",
  "Thorold",
  "Lincoln",
  "Pelham",
  "Fort Erie",
  "Grimsby",
];

// ─── Sub-components ──────────────────────────────────────────────────────────

function WaveLogo({ className = "" }) {
  return (
    <svg viewBox="0 0 40 40" className={className} fill="none" aria-hidden>
      <path
        d="M4 24 C 10 18, 14 30, 20 24 S 30 18, 36 24"
        stroke="currentColor"
        strokeWidth="2.4"
        strokeLinecap="round"
      />
      <path
        d="M6 30 C 12 25, 16 35, 22 30 S 30 25, 34 30"
        stroke="currentColor"
        strokeWidth="2.4"
        strokeLinecap="round"
        opacity="0.5"
      />
    </svg>
  );
}

function FallsIllustration({ className = "" }) {
  return (
    <svg viewBox="0 0 600 800" className={className} fill="none" aria-hidden>
      <defs>
        <linearGradient id="falls" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="#7ec8ee" stopOpacity="0.0" />
          <stop offset="40%" stopColor="#5fb6e8" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#0a1f4d" stopOpacity="0.85" />
        </linearGradient>
        <linearGradient id="falls2" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="#5fb6e8" stopOpacity="0" />
          <stop offset="60%" stopColor="#2b8fd9" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#0a1f4d" stopOpacity="0.9" />
        </linearGradient>
      </defs>
      <g className="drift">
        <path
          d="M120 60 C 180 220, 100 360, 220 540 C 280 640, 380 700, 460 760"
          stroke="url(#falls)"
          strokeWidth="120"
          strokeLinecap="round"
          opacity="0.55"
        />
        <path
          d="M260 20 C 340 220, 220 380, 360 560 C 420 640, 500 700, 560 760"
          stroke="url(#falls2)"
          strokeWidth="60"
          strokeLinecap="round"
          opacity="0.7"
        />
      </g>
      <g className="shimmer">
        <circle cx="450" cy="660" r="80" fill="#7ec8ee" opacity="0.18" />
        <circle cx="380" cy="710" r="50" fill="#5fb6e8" opacity="0.22" />
      </g>
    </svg>
  );
}

function Stat({ n, label }) {
  return (
    <div>
      <div className="font-display text-3xl md:text-4xl font-medium text-[var(--navy)]">
        {n}
      </div>
      <div className="mt-1 text-xs uppercase tracking-[0.18em] text-[var(--ink-soft)]">
        {label}
      </div>
    </div>
  );
}

function InputField({ name, label, placeholder, type = "text" }) {
  return (
    <label className="block">
      <span className="eyebrow text-[var(--ink-soft)]">{label}</span>
      <input
        required
        name={name}
        type={type}
        placeholder={placeholder}
        className="mt-2 w-full rounded-xl border border-[var(--rule)] bg-white px-4 py-3 text-[15px] text-[var(--navy)] placeholder-[var(--ink-soft)]/50 outline-none transition focus:border-[var(--blue)] focus:ring-4 focus:ring-[var(--blue)]/15"
      />
    </label>
  );
}

function TextArea({ name, label, placeholder }) {
  return (
    <label className="block">
      <span className="eyebrow text-[var(--ink-soft)]">{label}</span>
      <textarea
        name={name}
        rows={3}
        placeholder={placeholder}
        className="mt-2 w-full resize-none rounded-xl border border-[var(--rule)] bg-white px-4 py-3 text-[15px] text-[var(--navy)] placeholder-[var(--ink-soft)]/50 outline-none transition focus:border-[var(--blue)] focus:ring-4 focus:ring-[var(--blue)]/15"
      />
    </label>
  );
}

function SelectField({ name, label, options }) {
  return (
    <label className="block">
      <span className="eyebrow text-[var(--ink-soft)]">{label}</span>
      <select
        name={name}
        defaultValue=""
        className="mt-2 w-full rounded-xl border border-[var(--rule)] bg-white px-4 py-3 text-[15px] text-[var(--navy)] outline-none transition focus:border-[var(--blue)] focus:ring-4 focus:ring-[var(--blue)]/15"
      >
        <option value="" disabled>Select one…</option>
        {options.map((o) => (
          <option key={o} value={o}>{o}</option>
        ))}
      </select>
    </label>
  );
}

// ─── Sections ────────────────────────────────────────────────────────────────

function Nav() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <div className="mx-auto max-w-[1400px] px-4 lg:px-10 py-4">
        <nav className="flex items-center justify-between rounded-full border border-[var(--rule)] bg-[rgba(250,247,242,0.78)] backdrop-blur-md px-4 lg:px-6 py-2.5 shadow-[0_10px_40px_-20px_rgba(10,31,77,0.25)]">
          <a href="#top" className="flex items-center gap-2.5 min-w-0">
            <WaveLogo className="h-7 w-7 flex-shrink-0 text-[var(--navy)]" />
            <span className="font-display text-[15px] lg:text-[17px] font-semibold tracking-tight text-[var(--navy)] truncate">
              Crystal Clean <span className="font-display-soft text-[var(--blue)]">Niagara</span>
            </span>
          </a>
          <div className="hidden md:flex items-center gap-7 text-sm text-[var(--ink-soft)]">
            <a href="#services" className="hover:text-[var(--navy)] transition-colors">Services</a>
            <a href="#process" className="hover:text-[var(--navy)] transition-colors">Process</a>
            <a href="#area" className="hover:text-[var(--navy)] transition-colors">Service Area</a>
            <a href="#contact" className="hover:text-[var(--navy)] transition-colors">Contact</a>
          </div>
          <a href="#contact" className="btn-primary !py-2 !px-4 text-sm flex-shrink-0">
            Get a quote <ArrowUpRight className="h-4 w-4" strokeWidth={1.6} />
          </a>
        </nav>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="hero-bg grain relative overflow-hidden pt-36 pb-24 md:pt-44 md:pb-36">
      {/* Decorative blobs */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-32 -right-24 h-[42rem] w-[42rem] rounded-full bg-[radial-gradient(circle_at_30%_30%,rgba(126,200,238,0.45),transparent_55%)] drift" />
        <div className="absolute -bottom-40 -left-20 h-[38rem] w-[38rem] rounded-full bg-[radial-gradient(circle_at_70%_70%,rgba(43,143,217,0.30),transparent_60%)] drift" style={{ animationDelay: "-6s" }} />
      </div>

      <FallsIllustration className="pointer-events-none absolute right-[-8%] top-[18%] hidden lg:block w-[640px] opacity-90" />

      <div className="relative mx-auto max-w-[1400px] px-4 lg:px-10">
        {/* FIX: overflow-hidden on grid to contain blobs */}
        <div className="grid grid-cols-12 gap-y-10 lg:gap-y-0 overflow-hidden">
          {/* Left column */}
          <div className="col-span-12 lg:col-span-8">
            <div className="rise-1 inline-flex items-center gap-2 rounded-full border border-[var(--rule)] bg-white/60 px-3.5 py-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--blue)] shimmer" />
              <span className="eyebrow text-[var(--navy)]">Now booking — Niagara region</span>
            </div>

            <h1 className="rise-2 font-display mt-8 text-[clamp(2.8rem,8vw,7.5rem)] leading-[0.92] font-medium text-[var(--navy)]">
              Cleaning, with the<br />
              <span className="font-display-soft text-[var(--blue)]">clarity</span>
              <span className="text-[var(--navy)]"> of the Falls.</span>
            </h1>

            <p className="rise-3 mt-8 max-w-xl text-lg leading-relaxed text-[var(--ink-soft)]">
              A small cleaning crew based in the Niagara region. We work from a checklist built around your space, with the same team each visit and no surprises on the bill.
            </p>

            <div className="rise-4 mt-10 flex flex-wrap items-center gap-3">
              <a href="#contact" className="btn-primary">
                Request a walkthrough <ArrowUpRight className="h-4 w-4" strokeWidth={1.6} />
              </a>
              <a href="tel:+19059320148" className="btn-ghost">
                <Phone className="h-4 w-4" strokeWidth={1.6} /> (905) 932-0148
              </a>
            </div>

            <div className="rise-5 mt-14 grid max-w-2xl grid-cols-3 gap-6">
              <Stat n="Since 2025" label="Niagara-based" />
              <Stat n="29" label="Active clients" />
              <Stat n="9 cities" label="Across the region" />
            </div>
          </div>

          {/* Right column — card */}
          <div className="col-span-12 lg:col-span-4 relative lg:pl-6">
            <div className="rise-3 relative">
              <div className="aspect-[4/5] w-full overflow-hidden rounded-[2.5rem] border border-[var(--rule)] bg-gradient-to-br from-[var(--mist)] via-white to-[var(--paper)] shadow-[0_40px_120px_-50px_rgba(10,31,77,0.45)]">
                <div className="relative h-full w-full">
                  <img
                    src="/crystal-clean-niagara-logo.jpeg"
                    alt="Crystal Clean Niagara logo"
                    className="absolute inset-0 h-full w-full object-contain p-6"
                  />
                  <svg aria-hidden className="absolute bottom-0 left-0 w-full" viewBox="0 0 800 200" fill="none">
                    <path className="shimmer" d="M0 130 Q200 90 400 130 T800 130 V200 H0 Z" fill="url(#wgrad)" opacity="0.4" />
                    <path className="shimmer" style={{ animationDelay: "-2s" }} d="M0 160 Q200 130 400 160 T800 160 V200 H0 Z" fill="url(#wgrad2)" opacity="0.55" />
                    <defs>
                      <linearGradient id="wgrad" x1="0" x2="0" y1="0" y2="1">
                        <stop offset="0%" stopColor="#5fb6e8" />
                        <stop offset="100%" stopColor="#2b8fd9" />
                      </linearGradient>
                      <linearGradient id="wgrad2" x1="0" x2="0" y1="0" y2="1">
                        <stop offset="0%" stopColor="#2b8fd9" />
                        <stop offset="100%" stopColor="#0a1f4d" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
              </div>

              <div className="absolute -left-6 -bottom-8 hidden md:flex w-64 items-center gap-3 rounded-2xl border border-[var(--rule)] bg-white/90 p-3.5 backdrop-blur shadow-[0_20px_50px_-30px_rgba(10,31,77,0.35)]">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-[var(--mist)] text-[var(--navy)]">
                  <Leaf className="h-5 w-5" strokeWidth={1.5} />
                </div>
                <div className="leading-tight">
                  <div className="text-[13px] font-medium text-[var(--navy)]">Low-VOC products</div>
                  <div className="text-xs text-[var(--ink-soft)]">Pet &amp; kid-safe by default</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Marquee() {
  const items = ["Locally owned", "Residential & commercial", "Eco-conscious products", "Pet & kid-friendly", "Niagara-based", "Honest, plain quotes"];
  const doubled = [...items, ...items];
  return (
    <section aria-label="Highlights" className="border-y border-[var(--rule)] bg-[var(--paper)] py-6 overflow-hidden w-full">
      <div className="marquee wave">
        {doubled.map((t, i) => (
          <div key={i} className="flex items-center gap-4 text-[var(--navy)]">
            <Sparkles className="h-4 w-4 text-[var(--blue)] flex-shrink-0" strokeWidth={1.5} />
            <span className="font-display-soft text-2xl whitespace-nowrap">{t}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="relative py-28 md:py-36 overflow-hidden">
      <div className="mx-auto max-w-[1400px] px-4 lg:px-10">
        <div className="grid grid-cols-12 gap-8 mb-16">
          <div className="col-span-12 md:col-span-5">
            <div className="eyebrow text-[var(--blue)]">01 — What we do</div>
            <h2 className="mt-4 font-display text-5xl md:text-6xl font-medium leading-[0.95] text-[var(--navy)]">
              A handful of services,<br />done{" "}
              <span className="font-display-soft text-[var(--blue)]">obsessively</span> well.
            </h2>
          </div>
          <div className="col-span-12 md:col-span-6 md:col-start-7 self-end">
            <p className="text-lg leading-relaxed text-[var(--ink-soft)]">
              We do not pretend to clean carpets, ducts, or chimneys. We clean surfaces, glass, and the parts of a building you actually touch — and we do that in a way you will notice the moment you walk back in.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-5 auto-rows-[minmax(180px,auto)]">
          {services.map((svc, i) => {
            const Icon = svc.icon;
            return (
              <article
                key={svc.title}
                className={`tile ${svc.span} group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-[var(--rule)] bg-white p-7 md:p-9`}
              >
                <div className="absolute -right-16 -top-16 h-44 w-44 rounded-full bg-[radial-gradient(circle,rgba(126,200,238,0.5),transparent_70%)] opacity-0 transition-opacity duration-700 group-hover:opacity-100" />
                <div className="flex items-start justify-between">
                  <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[var(--mist)] text-[var(--navy)]">
                    <Icon className="h-5 w-5" strokeWidth={1.5} />
                  </div>
                  <span className="font-display text-xs tracking-[0.22em] text-[var(--ink-soft)]">/{String(i + 1).padStart(2, "0")}</span>
                </div>
                <div className="mt-10">
                  <h3 className="font-display text-2xl md:text-[28px] font-medium leading-tight text-[var(--navy)]">{svc.title}</h3>
                  <p className="mt-3 max-w-md text-[15px] leading-relaxed text-[var(--ink-soft)]">{svc.description}</p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {svc.keywords.map((k) => (
                      <span key={k} className="rounded-full border border-[var(--rule)] px-3 py-1 text-xs text-[var(--ink-soft)]">{k}</span>
                    ))}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function WhyUs() {
  const pillars = [
    { icon: ShieldCheck, title: "Insured and accountable", body: "Fully insured for residential and commercial work. We carry the paperwork so a slip-up never lands on you." },
    { icon: Leaf, title: "Products we'd use at home", body: "Low-VOC and biodegradable by default. Fragrance-light, friendly to pets and kids, and gentle on the watershed we share." },
    { icon: CalendarCheck, title: "A consistent crew", body: "The same small team handles your space each visit, so the standard never slips and nothing has to be re-explained." },
  ];
  return (
    <section className="section-dark relative overflow-hidden py-28 md:py-36">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/4 h-[30rem] w-[30rem] rounded-full bg-[radial-gradient(circle,rgba(126,200,238,0.18),transparent_60%)] drift" />
      </div>
      <div className="relative mx-auto max-w-[1400px] px-4 lg:px-10">
        <div className="max-w-2xl">
          <div className="eyebrow text-[var(--blue-light)]">02 — Why we are different</div>
          <h2 className="mt-4 font-display text-5xl md:text-6xl font-medium leading-[0.95]">
            We treat your home<br />like a{" "}
            <span className="font-display-soft text-[var(--blue-light)]">repeat guest</span>, not a job.
          </h2>
        </div>
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-px bg-white/10 rounded-3xl overflow-hidden border border-white/10">
          {pillars.map((p) => {
            const Icon = p.icon;
            return (
              <div key={p.title} className="bg-[var(--navy)] p-9 md:p-10">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-white/10 text-[var(--blue-light)]">
                  <Icon className="h-5 w-5" strokeWidth={1.5} />
                </div>
                <h3 className="mt-8 font-display text-xl font-medium leading-snug text-white">{p.title}</h3>
                <p className="mt-3 text-[15px] leading-relaxed text-[var(--mist-2)]">{p.body}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Process() {
  return (
    <section id="process" className="relative py-28 md:py-36 bg-[var(--cream)] overflow-hidden">
      <div className="mx-auto max-w-[1400px] px-4 lg:px-10">
        <div className="grid grid-cols-12 gap-8 mb-16">
          <div className="col-span-12 md:col-span-7 md:col-start-2">
            <div className="eyebrow text-[var(--blue)]">03 — How it works</div>
            <h2 className="mt-4 font-display text-5xl md:text-6xl font-medium leading-[0.95] text-[var(--navy)]">
              <span className="font-display-soft text-[var(--blue)]">Hourly</span>, until<br />the job is done.
            </h2>
          </div>
        </div>
        <ol className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-14 md:gap-y-20">
          {process.map((step, i) => (
            <li key={step.n} className={`relative flex gap-7 ${i % 2 === 1 ? "md:translate-y-16" : ""}`}>
              <div className="flex-shrink-0">
                <div className="font-display text-7xl md:text-8xl font-medium leading-none text-[var(--blue)]/85">{step.n}</div>
              </div>
              <div className="pt-3 md:pt-5">
                <h3 className="font-display text-2xl md:text-3xl font-medium text-[var(--navy)]">{step.title}</h3>
                <p className="mt-3 max-w-md text-[15px] leading-relaxed text-[var(--ink-soft)]">{step.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="relative py-28 md:py-36 bg-[var(--paper)] overflow-hidden">
      <div className="mx-auto max-w-[1400px] px-4 lg:px-10">
        <div className="flex items-end justify-between mb-16 gap-6 flex-wrap">
          <div>
            <div className="eyebrow text-[var(--blue)]">04 — What clients say</div>
            <h2 className="mt-4 font-display text-5xl md:text-6xl font-medium leading-[0.95] text-[var(--navy)] max-w-2xl">
              Quiet, careful,{" "}
              <span className="font-display-soft text-[var(--blue)]">repeatable.</span>
            </h2>
          </div>
          <div className="text-sm text-[var(--ink-soft)]">From recent client check-ins</div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {testimonials.map((t) => (
            <figure key={t.name} className="tile relative flex flex-col rounded-3xl border border-[var(--rule)] bg-white p-7 md:p-8">
              <Quote className="h-7 w-7 text-[var(--blue)]" strokeWidth={1.2} />
              <blockquote className="mt-5 font-display text-[20px] leading-snug text-[var(--navy)]">{t.quote}</blockquote>
              <figcaption className="mt-7 flex items-center gap-3 pt-5 border-t border-[var(--rule)]">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-[var(--navy)] text-[11px] font-medium tracking-wide text-white flex-shrink-0">{t.initials}</div>
                <div className="leading-tight">
                  <div className="text-[14px] font-medium text-[var(--navy)]">{t.name}</div>
                  <div className="text-xs text-[var(--ink-soft)]">{t.role}</div>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

function ServiceArea() {
  return (
    <section id="area" className="relative py-28 md:py-36 bg-[var(--cream)] overflow-hidden">
      <div className="mx-auto max-w-[1400px] px-4 lg:px-10">
        {/* FIX: gap-y-12 gap-x-6 instead of gap-12 */}
        <div className="grid grid-cols-12 gap-y-12 gap-x-6 items-center">
          <div className="col-span-12 md:col-span-5">
            <div className="eyebrow text-[var(--blue)]">05 — Where we work</div>
            <h2 className="mt-4 font-display text-5xl md:text-6xl font-medium leading-[0.95] text-[var(--navy)]">
              The whole<br />
              <span className="font-display-soft text-[var(--blue)]">peninsula</span>.
            </h2>
            <p className="mt-6 text-lg leading-relaxed text-[var(--ink-soft)] max-w-md">
              From the lake to the river — if it sits between Grimsby and Fort Erie, we can usually reach it. Outside that range, just ask.
            </p>
          </div>

          {/* FIX: min-w-0 overflow-hidden on the right column */}
          <div className="col-span-12 md:col-span-7 min-w-0 overflow-hidden">
            <ul className="grid grid-cols-2 sm:grid-cols-3 gap-x-3 sm:gap-x-8 gap-y-3 border-t border-[var(--rule)] pt-6">
              {cities.map((city) => (
                // FIX: min-w-0 on each list item
                <li key={city} className="group flex items-center gap-1.5 sm:gap-2 py-1 transition-colors hover:text-[var(--blue)] min-w-0">
                  <span className="font-display text-[15px] sm:text-lg md:text-xl text-[var(--navy)] group-hover:text-[var(--blue)] transition-colors min-w-0 break-words flex-1">{city}</span>
                  <Check className="h-3.5 w-3.5 sm:h-4 sm:w-4 flex-shrink-0 text-[var(--blue)] opacity-60 group-hover:opacity-100" strokeWidth={2} />
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

function Contact() {
  function handleSubmit(e) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const subject = encodeURIComponent("Quote request — Crystal Clean Niagara");
    const body = encodeURIComponent(
      `Name: ${data.get("name")}\nEmail: ${data.get("email")}\nPhone: ${data.get("phone")}\nProperty: ${data.get("property")}\nNotes: ${data.get("notes")}`
    );
    window.location.href = `mailto:crystalcleanniagara@gmail.com?subject=${subject}&body=${body}`;
  }

  return (
    <section id="contact" className="relative overflow-hidden">
      <div className="section-dark grain relative py-28 md:py-36">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 right-0 h-[36rem] w-[36rem] rounded-full bg-[radial-gradient(circle,rgba(126,200,238,0.22),transparent_60%)] drift" />
        </div>
        <div className="relative mx-auto max-w-[1400px] px-4 lg:px-10">
          {/* FIX: gap-y-12 gap-x-6 instead of gap-12 */}
          <div className="grid grid-cols-12 gap-y-12 gap-x-6">
            {/* Left */}
            <div className="col-span-12 md:col-span-7">
              <div className="eyebrow text-[var(--blue-light)]">06 — Get a quote</div>
              <h2 className="mt-4 font-display text-5xl md:text-7xl font-medium leading-[0.92] text-white">
                Let us walk<br />your space.
              </h2>
              <p className="mt-7 max-w-lg text-lg leading-relaxed text-[var(--mist-2)]">
                Most quotes go out within a day of the walkthrough. No pressure, no upsell, no follow-up phone tree — just an honest number and a sample checklist for your space.
              </p>
              <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-px bg-white/10 rounded-2xl overflow-hidden border border-white/10 max-w-xl">
                <a href="tel:+19059320148" className="group flex items-center gap-4 bg-[var(--navy)] p-6 transition-colors hover:bg-[var(--navy-soft)]">
                  <Phone className="h-5 w-5 flex-shrink-0 text-[var(--blue-light)]" strokeWidth={1.5} />
                  <div className="leading-tight min-w-0">
                    <div className="eyebrow text-[var(--blue-light)]">Call or text</div>
                    <div className="mt-1 font-display text-lg text-white">(905) 932-0148</div>
                  </div>
                </a>
                <a href="mailto:crystalcleanniagara@gmail.com" className="group flex items-center gap-4 bg-[var(--navy)] p-6 transition-colors hover:bg-[var(--navy-soft)] min-w-0">
                  <Mail className="h-5 w-5 flex-shrink-0 text-[var(--blue-light)]" strokeWidth={1.5} />
                  <div className="leading-tight min-w-0">
                    <div className="eyebrow text-[var(--blue-light)]">Email</div>
                    <div className="mt-1 font-display text-[15px] text-white break-all">crystalcleanniagara@gmail.com</div>
                  </div>
                </a>
                <div className="flex items-center gap-4 bg-[var(--navy)] p-6 sm:col-span-2">
                  <MapPin className="h-5 w-5 flex-shrink-0 text-[var(--blue-light)]" strokeWidth={1.5} />
                  <div className="leading-tight">
                    <div className="eyebrow text-[var(--blue-light)]">Based in</div>
                    <div className="mt-1 font-display text-lg text-white">Welland, Ontario · serving the Niagara region</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Form */}
            <form
              className="col-span-12 md:col-span-5 rounded-3xl bg-[var(--cream)] text-[var(--ink)] p-7 md:p-8 border border-white/10 shadow-[0_40px_120px_-40px_rgba(0,0,0,0.5)]"
              onSubmit={handleSubmit}
            >
              <div className="font-display text-2xl font-medium text-[var(--navy)]">Tell us about the space.</div>
              <div className="mt-6 grid gap-4">
                <InputField name="name" label="Your name" placeholder="Your full name" />
                <div className="grid grid-cols-2 gap-4">
                  <InputField name="email" label="Email" placeholder="you@domain.ca" type="email" />
                  <InputField name="phone" label="Phone" placeholder="(905) 000-0000" />
                </div>
                <SelectField
                  name="property"
                  label="Property type"
                  options={["Home / condo", "Office / commercial", "Post-construction", "Move-in / move-out", "Other"]}
                />
                <TextArea name="notes" label="Anything we should know?" placeholder="Square footage, frequency, pets, allergies, parking notes..." />
              </div>
              <button type="submit" className="btn-primary mt-6 w-full justify-center">
                Send request <ArrowUpRight className="h-4 w-4" strokeWidth={1.6} />
              </button>
              <div className="mt-3 text-[12px] text-[var(--ink-soft)] text-center">We reply within one business day.</div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-[var(--cream)] border-t border-[var(--rule)] py-12 overflow-hidden">
      <div className="mx-auto max-w-[1400px] px-4 lg:px-10">
        <div className="grid grid-cols-12 gap-8 items-end">
          <div className="col-span-12 md:col-span-6">
            <div className="flex items-center gap-2.5">
              <WaveLogo className="h-7 w-7 text-[var(--navy)]" />
              <span className="font-display text-[18px] font-semibold tracking-tight text-[var(--navy)]">
                Crystal Clean <span className="font-display-soft text-[var(--blue)]">Niagara</span>
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-[var(--ink-soft)]">
              Residential and commercial cleaning across the Niagara region. Locally based, fully insured, and easy to reach.
            </p>
          </div>
          <div className="col-span-6 md:col-span-3">
            <div className="eyebrow text-[var(--ink-soft)]">Site</div>
            <ul className="mt-4 space-y-2 text-sm">
              <li><a href="#services" className="text-[var(--navy)] hover:text-[var(--blue)]">Services</a></li>
              <li><a href="#process" className="text-[var(--navy)] hover:text-[var(--blue)]">Process</a></li>
              <li><a href="#area" className="text-[var(--navy)] hover:text-[var(--blue)]">Service area</a></li>
              <li><a href="#contact" className="text-[var(--navy)] hover:text-[var(--blue)]">Contact</a></li>
            </ul>
          </div>
          <div className="col-span-6 md:col-span-3">
            <div className="eyebrow text-[var(--ink-soft)]">Reach us</div>
            <ul className="mt-4 space-y-2 text-sm">
              <li className="text-[var(--navy)]">(905) 932-0148</li>
              <li className="text-[var(--navy)] break-all">crystalcleanniagara@gmail.com</li>
              <li className="text-[var(--ink-soft)]">Welland, ON</li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-6 border-t border-[var(--rule)] flex flex-wrap items-center justify-between gap-3 text-xs text-[var(--ink-soft)]">
          <div>© {new Date().getFullYear()} Crystal Clean Niagara · Welland, ON</div>
          <div className="font-display-soft text-base text-[var(--blue)]">Cleaning, with the clarity of the Falls.</div>
        </div>
      </div>
    </footer>
  );
}

// ─── App ─────────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <div className="min-h-screen bg-[var(--cream)] text-[var(--ink)]">
      <Nav />
      <Hero />
      <Marquee />
      <Services />
      <WhyUs />
      <Process />
      <Testimonials />
      <ServiceArea />
      <Contact />
      <Footer />
    </div>
  );
}
